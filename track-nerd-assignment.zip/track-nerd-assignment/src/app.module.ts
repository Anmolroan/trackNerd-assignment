import { Module } from '@nestjs/common';
import { PrismaModule } from 'prisma/prisma.module';
import { StudentModule } from './student/student.module';
import { TecherModule } from './techer/techer.module';

@Module({
  imports: [PrismaModule, StudentModule, TecherModule]
})
export class AppModule {}
