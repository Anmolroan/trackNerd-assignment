import { ApiProperty } from "@nestjs/swagger";
import {IsEmail,IsString,IsNotEmpty,Length, IsOptional, IsUUID} from "class-validator";


export class CreateTecherDto {
    @ApiProperty({
        description: 'The email of the User',
        example: 'a@gmail.com',
      })
    @IsNotEmpty()
    @IsString()
    @IsEmail()
    public email: string;

    @ApiProperty({
        description: 'The password of the User',
        example: '******',
      })
    @IsNotEmpty()
    @IsString()
    @Length(3,20,{message: "Password should be at between 3 and 20 characters"})
    public hash_password: string;

    @ApiProperty({
        description: 'The subjects for teachers',
        example: 'Coding',
      })
    @IsNotEmpty()
    @IsString()
    public subject: string;

    @ApiProperty({
        description: 'The courses for teachers',
        example: 'React',
      })
    @IsNotEmpty()
    @IsString()
    public courses: string;

    @ApiProperty({
        description: 'creation date',
        example: "date in string format",
      })
    @IsOptional()
    public created_at :string

    @ApiProperty({
        description: 'updation date',
        example: "date in string format",
      })
    @IsOptional()
    public updated_at :string

    @ApiProperty({
        description: 'class of student',
        example: "10",
      })
    @IsString()
    public class :string


}
