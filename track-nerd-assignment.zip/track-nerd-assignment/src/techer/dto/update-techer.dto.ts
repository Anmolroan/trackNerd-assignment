import { PartialType } from '@nestjs/mapped-types';
import { CreateTecherDto } from './create-techer.dto';

export class UpdateTecherDto extends PartialType(CreateTecherDto) {}
