import { ApiProperty } from "@nestjs/swagger";
import {IsEmail,IsString,IsNotEmpty,Length, IsOptional, IsUUID} from "class-validator";


export class TecherQueryDto {
    @ApiProperty({
        description: 'The subjects for teachers',
        example: 'Coding',
      })

    @IsString()
    @IsOptional()
    public subject: string;

    @ApiProperty({
        description: 'The courses for teachers',
        example: 'React',
      })

    @IsString()
    @IsOptional()
    public courses: string;

    @ApiProperty({
        description: 'class of student',
        example: "10",
      })
    @IsString()
    @IsOptional()
    public class :string


}


export class TecherQuerySortDto {
    @ApiProperty({
        description: 'get higher classes',
        example: '10',
      })
    @IsString()
    @IsOptional()
    public after: string;

    @ApiProperty({
        description: 'get lower than class',
        example: '10',
      })
      @IsOptional()
    @IsString()
    public before: string;



}
