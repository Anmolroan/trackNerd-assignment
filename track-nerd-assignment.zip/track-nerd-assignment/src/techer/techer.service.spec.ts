import { Test, TestingModule } from '@nestjs/testing';
import { TecherService } from './techer.service';

describe('TecherService', () => {
  let service: TecherService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [TecherService],
    }).compile();

    service = module.get<TecherService>(TecherService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
