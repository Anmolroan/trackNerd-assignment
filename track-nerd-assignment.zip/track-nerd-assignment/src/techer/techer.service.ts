import { BadRequestException, HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateTecherDto } from './dto/create-techer.dto';
import { UpdateTecherDto } from './dto/update-techer.dto';
import { PrismaService } from 'prisma/prisma.service';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class TecherService {
  constructor(private prisma: PrismaService) {}
  async create(createTecherDto: CreateTecherDto) {
    const { subject, courses, class: classname } = createTecherDto;
    try{
      const uniqueRecords: any = await this.prisma.teacher.findMany({
        where: {
          subject: subject,
          courses: courses,
          class: classname,
        },
        distinct: ['subject', 'courses', 'class'],
      });
      console.log(uniqueRecords);
      if (uniqueRecords.length>0) {
        throw new HttpException('Teacher is already present for the specific class', HttpStatus.CONFLICT)
      }
      const {hash_password,...createTecher} = await this.prisma.teacher.create({
        data: { ...createTecherDto, teacher_id: uuidv4() ,created_at:new Date().toISOString(),updated_at:new Date().toISOString()},
      });
      return createTecher;
    }catch(err){
      throw new HttpException(err.response, err.status)
    }
    }
 


  async findOne(id: string) {
    const teacher = await this.prisma.teacher.findUnique({
      where: {
        teacher_id: id,
      },
    });
    if (!teacher) {
      throw new HttpException('Teacher not found', HttpStatus.NOT_FOUND);
      
    }
    return teacher;
  }

  async signin(req:any) {
    const {email, hash_password} =req
    const teacher = await this.prisma.teacher.findMany({
      where: {
        email: email,
        hash_password: hash_password,
      },
    });
    if (!teacher) {
      throw new HttpException('Teacher not found', HttpStatus.NOT_FOUND);
      
    }
    // const user ={email,password:hash_password}

    return teacher[0];
  }

  async update(id: string, updateTecherDto: UpdateTecherDto) {
    const { subject, courses, class: classname ,email} = updateTecherDto;
    const uniqueRecords: any = await this.prisma.teacher.findMany({
      where: {
        subject: subject,
        courses: courses,
        class: classname,
        email:email
      },
      distinct: ['subject', 'courses', 'class','email'],
    });
    if (uniqueRecords.length) {
      throw new BadRequestException(
        'Teacher is already present use another credentials',
      );
    }
    const updatedUser = await this.prisma.teacher.update({
      where: { teacher_id:id },
      data: { ...updateTecherDto,updated_at:new Date().toISOString()},
    })
    return updatedUser;
  }

  async remove(id: string) {
    try{
      const deleteTeacher = await this.prisma.teacher.delete({
        where:{
          teacher_id:id
        }
      })
      return {success:true}
    }catch(err){
      throw new HttpException('Teacher not found', HttpStatus.NOT_FOUND)
    }

  }

  async findAllStudents(id: string){
    const teacher = await this.prisma.teacher.findUnique({
      where: {
        teacher_id: id,
      },
    });
    const { courses:course, class:classname,subject} = teacher;
  
    const result = await this.prisma.student.findMany({
      where: {
       class:classname,
      },
    })


    // await prisma.user.findMany({
    //   where: {
    //     extendedPetsData: {
    //       equals: json,
    //     },
    //   },
    // })

    return result
  }


  async findTeachers(query:any) {
    const { subject, courses, class: classname } = query;
    try{
      const records: any = await this.prisma.teacher.findMany({
        where: {
          subject: subject,
          courses: courses,
          class: classname,
        },
      });
      if (records.length===0) {
        throw new HttpException('No teacher found', HttpStatus.NOT_FOUND)
      }
      return records

    }catch(err){
      throw new HttpException(err.response, err.status)
    }
    }

    async sortTeacersByClass(query:any) {
      const {  class: classname ,after,before} = query;
      try{
        if(after){
          const teachers = await this.prisma.teacher.findMany({
            where: {
              class: {
                lte: after,
              },
            },
            orderBy: {
              class: 'asc',
            },
          });
          return teachers
        }else{
          const teachers = await this.prisma.teacher.findMany({
            where: {
              class: {
                gte: before,
              },
            },
            orderBy: {
              class: 'desc',
            },
          });
          return teachers
        }
  
      }catch(err){
        throw new HttpException(err.response, err.status)
      }
      }
}
