import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
  UseGuards,
  Res,
  Req,
  UnauthorizedException,
} from '@nestjs/common';
import { TecherService } from './techer.service';
import { CreateTecherDto } from './dto/create-techer.dto';
import { UpdateTecherDto } from './dto/update-techer.dto';
import { JwtService } from '@nestjs/jwt';
import { Response,Request } from 'express';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { LoginDtoTeacher } from 'src/student/dto/login.dto';
import { TeacherQuery } from 'src/entities/query.entities';
import { TecherQueryDto, TecherQuerySortDto } from './dto/teacher.dto';

@ApiBearerAuth()
@ApiTags('Teacher Api')
@Controller('teacher')
export class TecherController {
  constructor(
    private readonly techerService: TecherService,
    private jwtService:JwtService
  ) {}

  @Post('signup')
  @ApiOperation({ summary: 'create a teacher', description: 'Takes the request body and will create a teacher' })
  create(@Body() createTecherDto: CreateTecherDto) {
    return this.techerService.create(createTecherDto);
  }
  @Post('signin')
  @ApiOperation({ summary: 'signin a teacher', description: 'This will take the email and password and validate it ,After validation it will create a token which will be stored in cookies' })
  async signin(@Body() req: LoginDtoTeacher,@Res({passthrough: true}) response:Response) {
   const user = this.techerService.signin(req);
   const jwt = await this.jwtService.signAsync({email:req.email})
   response.cookie('jwt',jwt,{httpOnly:true})
   return {success:true};
  }
  @ApiOperation({summary: 'get all mapped students',description:"this api will get all the student form the same class and having course and subjects sam as teacher"})
  @Get(':id/mapped-students')
  findAllStudents(@Param('id') id: string) {
    return this.techerService.findAllStudents(id);
  }

  @ApiOperation({summary:"teacher filter",description:"get teacher by class ,subject and courses "})
  @Get('getall')
  findTeacers(@Query() query:TecherQueryDto) {
    return this.techerService.findTeachers(query);
  }
  @ApiOperation({summary:"teacher sorting",description:"sort teachers from class below or after "})
  @Get('class')
  sortTeacersByClass(@Query() query:TecherQuerySortDto) {
    return this.techerService.sortTeacersByClass(query);
  }

  @ApiOperation({summary:"get teacher by id",description:"id will be passed as params"})
  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.techerService.findOne(id);
  }

  @ApiOperation({summary:"patch teacher by id",description:"id will be passed as params"})
  @Patch(':id')
  async update(@Param('id') id: string, @Body() updateTecherDto: UpdateTecherDto, @Req()request:Request) {

    try{
      const cookie =request.cookies['jwt'];
      const data =await this.jwtService.verifyAsync(cookie)
      if(!data){
        throw new UnauthorizedException();
      }
      return this.techerService.update(id, updateTecherDto);
    }catch(err){
      throw new UnauthorizedException();
    }
    
  }

  @ApiOperation({summary:"Delete teacher by id",description:"id will be passed as params and will verify the jwt token before deleting"})
  @Delete(':id')
  async remove(@Param('id') id: string ,@Req()request:Request) {
    try{
      const cookie =request.cookies['jwt'];
      const data =await this.jwtService.verifyAsync(cookie)
      if(!data){
        throw new UnauthorizedException();
      }
      return this.techerService.remove(id);
    }catch(err){
      throw new UnauthorizedException();
    }
   
   
  }
}
