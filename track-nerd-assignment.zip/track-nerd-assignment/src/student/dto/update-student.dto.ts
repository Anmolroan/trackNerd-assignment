import {IsEmail,IsString,IsNotEmpty,Length, IsOptional, IsUUID} from "class-validator";

export class UpdateStudentDto {
    @IsString()
    @IsEmail()
    @IsOptional()
    public email: string;

    @IsNotEmpty()
    @IsString()
    @Length(3,20,{message: "Password should be at between 3 and 20 characters"})
    @IsOptional()
    public hashed_password: string;

    @IsOptional()
    public subjects: Array<string>;

    @IsOptional()
    public courses:Array<string>;

    @IsOptional()
    public created_at :string

    @IsOptional()
    public updated_at :string

    @IsString()
    @IsOptional()
    public class :string
}

