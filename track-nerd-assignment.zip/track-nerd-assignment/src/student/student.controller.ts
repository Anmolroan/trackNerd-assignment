import { Controller, Get, Post, Body, Patch, Param, Delete, Query, Res } from '@nestjs/common';
import { StudentService } from './student.service';
import { CreateStudentDto } from './dto/create-student.dto';
import { UpdateStudentDto } from './dto/update-student.dto';
import { JwtService } from '@nestjs/jwt';
import { Response,Request } from 'express';
import { LoginDtoStudent } from './dto/login.dto';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';

@ApiBearerAuth()
@ApiTags('Student Api')
@Controller('student')
export class StudentController {
  constructor(private readonly studentService: StudentService,
    private jwtService:JwtService
    ) {}
  @ApiOperation({ summary: 'create a student', description: 'Takes the request body and will create a student' })
  @Post("signup")
  create(@Body() createStudentDto: CreateStudentDto) {
    return this.studentService.create(createStudentDto);
  }

    @ApiOperation({ summary: 'signin a teacher',  description: 'This will take the email and password and validate it ,After validation it will create a token which will be stored in cookies' })
  @Post('signin')
  async signin(@Body() req: LoginDtoStudent,@Res({passthrough: true}) response:Response) {
   const user = this.studentService.signin(req);
   const jwt = await this.jwtService.signAsync({email:req.email})
   response.cookie('jwt',jwt,{httpOnly:true})
   return {success:true};
  }

    @ApiOperation({summary: 'get all mapped teachers',description:"this api will get all the teachers form the same class"})
  @Get(":id/mapped-teachers")
  findAllTeachers(@Param('id') id: string) {
    return this.studentService.findAllTeachers(id);
  }

    @ApiOperation({summary:"get student by id",description:"id will be passed as params"})
  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.studentService.findOne(id);
  }

    @ApiOperation({summary:"patch student by id",description:"id will be passed as params"})
  @Patch(':id')
  update(@Param('id') id: string, @Body() updateStudentDto: UpdateStudentDto) {
    return this.studentService.update(id, updateStudentDto);
  }

  @ApiOperation({summary:"Delete student by id",description:"id will be passed as params and will verify the jwt token before deleting"})
  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.studentService.remove(id);
  }
}
