import { Module } from '@nestjs/common';
import { StudentService } from './student.service';
import { StudentController } from './student.controller';
import { JwtModule } from '@nestjs/jwt';

@Module({
  imports:[JwtModule.register({
    secret: process.env.APP_SECRET, //should come from env
    signOptions:{expiresIn:'1d'}
  })],
  controllers: [StudentController],
  providers: [StudentService]
})
export class StudentModule {}
