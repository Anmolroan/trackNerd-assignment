import { BadRequestException, HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateStudentDto } from './dto/create-student.dto';
import { UpdateStudentDto } from './dto/update-student.dto';
import { PrismaService } from 'prisma/prisma.service';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class StudentService {
  constructor(private prisma: PrismaService) {}
  async create(createStudentDto: CreateStudentDto) {
    const {email,hashed_password:password} = createStudentDto;
    const uniqueRecords: any = await this.prisma.student.findMany({
      where: {
        hashed_password: password,
        email:email
      },
      distinct: ['hashed_password', 'email'],
    });
    if (uniqueRecords.length) {
      throw new BadRequestException(
        'student is already present ',
      );
    }
    const createStudent = await this.prisma.student.create({
      data: { ...createStudentDto, student_id: uuidv4() ,created_at:new Date().toISOString(),updated_at:new Date().toISOString()},
    });
    const{hashed_password,...restProps} = createStudent
    return restProps;
  }

  async findOne(id: string) {

    const student = await this.prisma.student.findUnique({
      where: {
        student_id: id,
      },
    });
    if (!student) {
      throw new HttpException('student not found', HttpStatus.NOT_FOUND)
    }
    return student;
  }

  async update(id: string, updateStudentDto: UpdateStudentDto) {

    const {email} = updateStudentDto;
    if(email){
      const uniqueRecords: any = await this.prisma.student.findMany({
        where: {
          email:email
        },
        distinct: ['email'],
      });
      if (uniqueRecords.length) {
        throw new BadRequestException(
          'another student is present with same credentials',
        );
      }
    }
   try{
    const updatedStudent = await this.prisma.student.update({
      where: { student_id:id },
      data: { ...updateStudentDto,updated_at:new Date().toISOString()},
    })
    return updatedStudent;
   }catch(err){
    throw new HttpException('student not found', HttpStatus.NOT_FOUND)
   }
    
    
  }

  async remove(id: string) {
    try{
      const deleteStudent = await this.prisma.student.delete({
        where:{
          student_id:id
        }
      })
      return {success:true}
    }catch(err){
      throw new HttpException('student not found', HttpStatus.NOT_FOUND)
    }

  }

  async findAllTeachers(id: string){
    const student = await this.prisma.student.findUnique({
      where: {
        student_id: id,
      },
    });
    const { courses:courseArr, class:classname} = student;


    const teacher= await this.prisma.teacher.findMany({
      where: {
        courses: {
          in:courseArr ,
        },
        class:classname
      },
    });
      return teacher

    // const result = await prisma.student.findMany({
    //   where: {
    //     columnName: {
    //       contains: 'searchTerm'
    //     }
    //   }
    // })
  }

  async signin(req:any) {
    const {email, hashed_password} =req
    const student = await this.prisma.student.findMany({
      where: {
        email: email,
        hashed_password: hashed_password,
      },
    });
    if (!student) {
      throw new HttpException('Student not found', HttpStatus.NOT_FOUND);
      
    }
    // const user ={email,password:hash_password}

    return student[0];
  }
}
