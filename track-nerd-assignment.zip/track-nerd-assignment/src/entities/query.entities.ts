
export interface TeacherQuery{
class:string;
subject:string;
courses:string
}