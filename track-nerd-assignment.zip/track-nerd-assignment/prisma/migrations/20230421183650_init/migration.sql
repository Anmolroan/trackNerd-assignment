-- CreateTable
CREATE TABLE "Student" (
    "student_id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "hashed_password" TEXT NOT NULL,
    "created_at" TEXT NOT NULL,
    "updated_at" TEXT NOT NULL,
    "subjects" TEXT[] DEFAULT ARRAY['Coding', 'Dsa']::TEXT[],
    "courses" TEXT[] DEFAULT ARRAY['Html', 'Css', 'Dsa101']::TEXT[],
    "class" TEXT NOT NULL
);

-- CreateTable
CREATE TABLE "Teacher" (
    "teacher_id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "hash_password" TEXT NOT NULL,
    "created_at" TEXT NOT NULL,
    "updated_at" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "courses" TEXT NOT NULL,
    "class" TEXT NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "Student_student_id_key" ON "Student"("student_id");

-- CreateIndex
CREATE UNIQUE INDEX "Student_email_key" ON "Student"("email");

-- CreateIndex
CREATE UNIQUE INDEX "Teacher_teacher_id_key" ON "Teacher"("teacher_id");

-- CreateIndex
CREATE UNIQUE INDEX "Teacher_email_key" ON "Teacher"("email");
