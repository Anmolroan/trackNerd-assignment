# To start the application below are the steps

### run the command 'npm i' to download all the packages


### configure the databse url in env and secret key 

### run the command 'npx prisma migrate dev --name init' to create the tables

### run 'npm run start:dev' to start he application

### to see the contract 'http://localhost:3000/api#/' 